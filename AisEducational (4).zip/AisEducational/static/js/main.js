/**
 * أكاديمية AiS للتكنولوجيا - الوظائف الأساسية
 */

// تهيئة التطبيق عند تحميل الصفحة
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
});

/**
 * تهيئة التطبيق الأساسية
 */
function initializeApp() {
    // تفعيل التولتيبس
    initializeTooltips();
    
    // تفعيل الرسوم المتحركة
    initializeAnimations();
    
    // إعداد النماذج
    initializeForms();
    
    // إعداد التنقل
    initializeNavigation();
    
    // إعداد التقييمات
    initializeAssessments();
    
    // إعداد لوحة التحكم
    initializeDashboard();
}

/**
 * تفعيل التولتيبس
 */
function initializeTooltips() {
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function(tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
}

/**
 * تفعيل الرسوم المتحركة
 */
function initializeAnimations() {
    // إضافة فئة الرسوم المتحركة للعناصر عند التمرير
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver(function(entries) {
        entries.forEach(function(entry) {
            if (entry.isIntersecting) {
                entry.target.classList.add('fade-in');
                observer.unobserve(entry.target);
            }
        });
    }, observerOptions);

    // مراقبة البطاقات والأقسام
    document.querySelectorAll('.card, .alert, .hero-section').forEach(function(element) {
        observer.observe(element);
    });
}

/**
 * إعداد النماذج
 */
function initializeForms() {
    // التحقق من صحة النماذج
    const forms = document.querySelectorAll('.needs-validation');
    forms.forEach(function(form) {
        form.addEventListener('submit', function(event) {
            if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
                
                // عرض رسالة خطأ
                showAlert('يرجى ملء جميع الحقول المطلوبة بشكل صحيح', 'danger');
            }
            form.classList.add('was-validated');
        });
    });

    // تحسين تجربة كلمة المرور
    initializePasswordToggle();
    
    // تحسين حقول البحث
    initializeSearchFields();
}

/**
 * إضافة وظيفة إظهار/إخفاء كلمة المرور
 */
function initializePasswordToggle() {
    const passwordFields = document.querySelectorAll('input[type="password"]');
    passwordFields.forEach(function(field) {
        const wrapper = document.createElement('div');
        wrapper.className = 'input-group';
        
        field.parentNode.insertBefore(wrapper, field);
        wrapper.appendChild(field);
        
        const toggleBtn = document.createElement('button');
        toggleBtn.className = 'btn btn-outline-secondary';
        toggleBtn.type = 'button';
        toggleBtn.innerHTML = '<i class="fas fa-eye"></i>';
        
        const toggleSpan = document.createElement('span');
        toggleSpan.className = 'input-group-text';
        toggleSpan.appendChild(toggleBtn);
        wrapper.appendChild(toggleSpan);
        
        toggleBtn.addEventListener('click', function() {
            const type = field.getAttribute('type') === 'password' ? 'text' : 'password';
            field.setAttribute('type', type);
            
            const icon = toggleBtn.querySelector('i');
            icon.className = type === 'password' ? 'fas fa-eye' : 'fas fa-eye-slash';
        });
    });
}

/**
 * تحسين حقول البحث
 */
function initializeSearchFields() {
    const searchFields = document.querySelectorAll('input[type="search"], .search-input');
    searchFields.forEach(function(field) {
        field.addEventListener('input', debounce(function() {
            const query = this.value.toLowerCase();
            performSearch(query);
        }, 300));
    });
}

/**
 * إعداد التنقل
 */
function initializeNavigation() {
    // تفعيل الرابط النشط
    const currentPath = window.location.pathname;
    const navLinks = document.querySelectorAll('.navbar-nav .nav-link');
    
    navLinks.forEach(function(link) {
        if (link.getAttribute('href') === currentPath) {
            link.classList.add('active');
        }
    });

    // تحسين قائمة الهاتف المحمول
    const navbarToggler = document.querySelector('.navbar-toggler');
    const navbarCollapse = document.querySelector('.navbar-collapse');
    
    if (navbarToggler && navbarCollapse) {
        navLinks.forEach(function(link) {
            link.addEventListener('click', function() {
                if (window.innerWidth < 992) {
                    navbarCollapse.classList.remove('show');
                }
            });
        });
    }
}

/**
 * إعداد التقييمات
 */
function initializeAssessments() {
    const assessmentForm = document.getElementById('assessmentForm');
    if (assessmentForm) {
        // حفظ الإجابات في التخزين المحلي
        initializeAutoSave();
        
        // تحديث شريط التقدم
        updateAssessmentProgress();
        
        // إضافة مستمعي الأحداث للأسئلة
        const questionInputs = assessmentForm.querySelectorAll('input[type="radio"], input[type="checkbox"]');
        questionInputs.forEach(function(input) {
            input.addEventListener('change', function() {
                updateAssessmentProgress();
                autoSaveAnswers();
            });
        });
    }
}

/**
 * حفظ تلقائي للإجابات
 */
function initializeAutoSave() {
    const assessmentId = getAssessmentId();
    if (!assessmentId) return;

    // استرداد الإجابات المحفوظة
    const savedAnswers = localStorage.getItem(`assessment_${assessmentId}`);
    if (savedAnswers) {
        const answers = JSON.parse(savedAnswers);
        restoreAnswers(answers);
    }

    // حفظ عند مغادرة الصفحة
    window.addEventListener('beforeunload', function() {
        autoSaveAnswers();
    });
}

/**
 * حفظ الإجابات تلقائياً
 */
function autoSaveAnswers() {
    const assessmentId = getAssessmentId();
    if (!assessmentId) return;

    const form = document.getElementById('assessmentForm');
    if (!form) return;

    const answers = {};
    const inputs = form.querySelectorAll('input[type="radio"]:checked, input[type="checkbox"]:checked');
    
    inputs.forEach(function(input) {
        answers[input.name] = input.value;
    });

    localStorage.setItem(`assessment_${assessmentId}`, JSON.stringify(answers));
    
    // عرض رسالة الحفظ
    showTemporaryMessage('تم حفظ الإجابات تلقائياً', 'success', 2000);
}

/**
 * استرداد الإجابات المحفوظة
 */
function restoreAnswers(answers) {
    Object.keys(answers).forEach(function(name) {
        const input = document.querySelector(`input[name="${name}"][value="${answers[name]}"]`);
        if (input) {
            input.checked = true;
        }
    });
}

/**
 * الحصول على معرف التقييم
 */
function getAssessmentId() {
    const form = document.getElementById('assessmentForm');
    if (!form) return null;
    
    const action = form.getAttribute('action');
    const match = action.match(/assessment\/(\d+)\/submit/);
    return match ? match[1] : null;
}

/**
 * تحديث شريط تقدم التقييم
 */
function updateAssessmentProgress() {
    const form = document.getElementById('assessmentForm');
    if (!form) return;

    const totalQuestions = form.querySelectorAll('[name^="question_"]').length / 2; // تقسيم على 2 لأن كل سؤال له خيارين على الأقل
    const answeredQuestions = new Set();
    
    const checkedInputs = form.querySelectorAll('input[type="radio"]:checked, input[type="checkbox"]:checked');
    checkedInputs.forEach(function(input) {
        const questionName = input.name;
        answeredQuestions.add(questionName);
    });

    const progress = (answeredQuestions.size / totalQuestions) * 100;
    
    const progressBar = document.getElementById('progressBar');
    const answeredCount = document.getElementById('answeredCount');
    
    if (progressBar) {
        progressBar.style.width = progress + '%';
        progressBar.textContent = Math.round(progress) + '%';
    }
    
    if (answeredCount) {
        answeredCount.textContent = answeredQuestions.size;
    }
}

/**
 * إعداد لوحة التحكم
 */
function initializeDashboard() {
    // تحديث الإحصائيات في الوقت الفعلي
    updateDashboardStats();
    
    // إضافة رسوم بيانية
    initializeCharts();
    
    // تحديث دوري للبيانات
    setInterval(updateDashboardStats, 30000); // كل 30 ثانية
}

/**
 * تحديث إحصائيات لوحة التحكم
 */
function updateDashboardStats() {
    // يمكن إضافة طلبات AJAX هنا لتحديث الإحصائيات
    // fetch('/api/dashboard-stats')
    //     .then(response => response.json())
    //     .then(data => {
    //         // تحديث العناصر
    //     });
}

/**
 * تهيئة الرسوم البيانية
 */
function initializeCharts() {
    // رسم بياني لتقدم الطلاب
    const progressChart = document.getElementById('progressChart');
    if (progressChart) {
        // يمكن استخدام Chart.js هنا
        // const ctx = progressChart.getContext('2d');
        // new Chart(ctx, {
        //     type: 'doughnut',
        //     data: { ... },
        //     options: { ... }
        // });
    }
}

/**
 * عرض رسالة تنبيه
 */
function showAlert(message, type = 'info', duration = 5000) {
    const alertContainer = document.querySelector('.container');
    if (!alertContainer) return;

    const alert = document.createElement('div');
    alert.className = `alert alert-${type} alert-dismissible fade show`;
    alert.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;

    alertContainer.insertBefore(alert, alertContainer.firstChild);

    // إزالة تلقائية
    setTimeout(function() {
        alert.remove();
    }, duration);
}

/**
 * عرض رسالة مؤقتة
 */
function showTemporaryMessage(message, type = 'info', duration = 3000) {
    // إنشاء عنصر الرسالة
    const messageEl = document.createElement('div');
    messageEl.className = `alert alert-${type} position-fixed`;
    messageEl.style.cssText = `
        top: 20px;
        left: 50%;
        transform: translateX(-50%);
        z-index: 9999;
        min-width: 300px;
        text-align: center;
    `;
    messageEl.textContent = message;

    document.body.appendChild(messageEl);

    // إزالة بعد المدة المحددة
    setTimeout(function() {
        messageEl.remove();
    }, duration);
}

/**
 * تأخير تنفيذ الدالة
 */
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func.apply(this, args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

/**
 * تنفيذ البحث
 */
function performSearch(query) {
    // البحث في المقررات
    const courseCards = document.querySelectorAll('.course-card');
    courseCards.forEach(function(card) {
        const title = card.querySelector('.card-title')?.textContent.toLowerCase() || '';
        const description = card.querySelector('.card-text')?.textContent.toLowerCase() || '';
        
        if (title.includes(query) || description.includes(query)) {
            card.style.display = 'block';
        } else {
            card.style.display = 'none';
        }
    });
}

/**
 * تنسيق التاريخ والوقت
 */
function formatDateTime(dateString) {
    const date = new Date(dateString);
    const options = {
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    };
    return date.toLocaleDateString('ar-SA', options);
}

/**
 * تحسين الاستجابة للأجهزة المحمولة
 */
function optimizeForMobile() {
    const isMobile = window.innerWidth <= 768;
    
    if (isMobile) {
        // تحسين الجداول للأجهزة المحمولة
        const tables = document.querySelectorAll('.table-responsive');
        tables.forEach(function(table) {
            table.style.fontSize = '0.875rem';
        });
        
        // تحسين البطاقات
        const cards = document.querySelectorAll('.card');
        cards.forEach(function(card) {
            card.style.marginBottom = '1rem';
        });
    }
}

/**
 * إدارة التخزين المحلي
 */
const storage = {
    set: function(key, value) {
        try {
            localStorage.setItem(key, JSON.stringify(value));
        } catch (e) {
            console.warn('لا يمكن حفظ البيانات في التخزين المحلي:', e);
        }
    },
    
    get: function(key) {
        try {
            const item = localStorage.getItem(key);
            return item ? JSON.parse(item) : null;
        } catch (e) {
            console.warn('لا يمكن قراءة البيانات من التخزين المحلي:', e);
            return null;
        }
    },
    
    remove: function(key) {
        try {
            localStorage.removeItem(key);
        } catch (e) {
            console.warn('لا يمكن حذف البيانات من التخزين المحلي:', e);
        }
    }
};

/**
 * وظائف المساعدة
 */
const utils = {
    // تنظيف النص
    sanitizeText: function(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    },
    
    // تحويل النص إلى رابط
    slugify: function(text) {
        return text
            .toLowerCase()
            .replace(/[^a-z0-9\u0600-\u06FF]/g, '-')
            .replace(/-+/g, '-')
            .replace(/^-|-$/g, '');
    },
    
    // نسخ النص إلى الحافظة
    copyToClipboard: function(text) {
        if (navigator.clipboard) {
            navigator.clipboard.writeText(text).then(function() {
                showTemporaryMessage('تم نسخ النص بنجاح', 'success');
            });
        } else {
            // طريقة احتياطية للمتصفحات القديمة
            const textArea = document.createElement('textarea');
            textArea.value = text;
            document.body.appendChild(textArea);
            textArea.select();
            document.execCommand('copy');
            document.body.removeChild(textArea);
            showTemporaryMessage('تم نسخ النص بنجاح', 'success');
        }
    }
};

// استدعاء تحسين الاستجابة عند تغيير حجم النافذة
window.addEventListener('resize', debounce(optimizeForMobile, 250));

// تطبيق التحسينات عند التحميل
window.addEventListener('load', function() {
    optimizeForMobile();
    
    // إزالة البيانات المحفوظة للتقييمات المكتملة
    const completedAssessments = document.querySelectorAll('.assessment-completed');
    completedAssessments.forEach(function(assessment) {
        const assessmentId = assessment.dataset.assessmentId;
        if (assessmentId) {
            storage.remove(`assessment_${assessmentId}`);
        }
    });
});

// تصدير الوظائف للاستخدام العام
window.AiSAcademy = {
    showAlert,
    showTemporaryMessage,
    storage,
    utils,
    debounce
};
