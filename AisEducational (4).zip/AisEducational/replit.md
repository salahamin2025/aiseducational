# Education Platform - أكاديمية AiS للتكنولوجيا

## Overview

This is a comprehensive Arabic-language education platform built with Flask that provides course management, user authentication, and assessment capabilities. The platform supports both student and admin roles, offering a complete learning management system with multimedia content support.

## System Architecture

### Backend Architecture
- **Framework**: Flask (Python web framework)
- **Database**: SQLAlchemy ORM with SQLite (development) / PostgreSQL (production support)
- **Authentication**: Flask-Login for session management
- **Forms**: Flask-WTF for form handling and validation
- **Security**: Werkzeug for password hashing and security utilities

### Frontend Architecture
- **Template Engine**: Jinja2 (Flask's default)
- **CSS Framework**: Bootstrap 5 RTL (Right-to-Left for Arabic)
- **Icons**: Font Awesome 6.4.0
- **Typography**: Google Fonts (Cairo for Arabic text)
- **JavaScript**: Vanilla JS with Bootstrap components

### Database Schema
The application uses a relational database with the following key entities:
- **User**: Stores user credentials and profile information
- **Course**: Contains course content, descriptions, and multimedia links
- **Assessment**: Manages quizzes and evaluations
- **Question**: Individual assessment questions with multiple types
- **Enrollment**: Tracks user course registrations and progress
- **AssessmentResult**: Stores quiz results and scores

## Key Components

### Authentication System
- User registration and login functionality
- Role-based access control (admin/student)
- Session management with Flask-Login
- Password hashing with Werkzeug security

### Course Management
- Course creation and editing (admin only)
- Rich content support (text, images, videos)
- Course enrollment system
- Progress tracking for students

### Assessment System
- Multiple question types (true/false, multiple choice)
- Timed assessments with JavaScript countdown
- Automatic scoring and result tracking
- Question bank management

### User Interface
- Fully Arabic-localized interface
- Responsive design with Bootstrap 5 RTL
- Clean, modern design with consistent branding
- Mobile-friendly navigation and layouts

## Data Flow

### User Authentication Flow
1. User submits login credentials via LoginForm
2. Credentials validated against User model
3. Flask-Login manages session state
4. Role-based routing (admin vs student dashboard)

### Course Enrollment Flow
1. Student browses published courses
2. Enrollment creates record in Enrollment table
3. Progress tracking updates as content is consumed
4. Completion status tracked per user/course pair

### Assessment Flow
1. Admin creates assessment with associated questions
2. Students access published assessments
3. JavaScript handles timing and form submission
4. Results calculated and stored in AssessmentResult
5. Detailed feedback provided to students

## External Dependencies

### Python Packages
- Flask: Web framework
- Flask-SQLAlchemy: ORM and database abstraction
- Flask-Login: Authentication management
- Flask-WTF: Form handling and CSRF protection
- WTForms: Form validation
- Werkzeug: Security utilities

### Frontend Dependencies
- Bootstrap 5 RTL: UI framework with Arabic support
- Font Awesome: Icon library
- Google Fonts (Cairo): Arabic typography
- JavaScript: Modern browser APIs for interactive features

### Development Dependencies
- SQLite: Development database
- Python 3.x: Runtime environment

## Deployment Strategy

### Environment Configuration
- Configuration via environment variables
- `DATABASE_URL` for database connection
- `SESSION_SECRET` for Flask sessions
- Debug mode configurable for development

### Production Considerations
- Proxy configuration with ProxyFix middleware
- Database connection pooling with pre-ping enabled
- Session security with configurable secret keys
- Static file serving optimization recommended

### Scalability Features
- ORM abstraction supports multiple database backends
- Modular structure allows for microservice migration
- Static assets can be served via CDN
- Session state can be moved to external store

## Changelog

```
Changelog:
- June 29, 2025. Initial setup
```

## User Preferences

```
Preferred communication style: Simple, everyday language.
```