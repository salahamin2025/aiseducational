from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, TextAreaField, SelectField, IntegerField, BooleanField, RadioField
from wtforms.validators import DataRequired, Email, Length, EqualTo, Optional
from wtforms.widgets import TextArea

class LoginForm(FlaskForm):
    username = StringField('اسم المستخدم', validators=[DataRequired(), Length(min=3, max=80)])
    password = PasswordField('كلمة المرور', validators=[DataRequired()])

class CreateUserForm(FlaskForm):
    username = StringField('اسم المستخدم', validators=[DataRequired(), Length(min=3, max=80)])
    email = StringField('البريد الإلكتروني', validators=[DataRequired(), Email()])
    full_name = StringField('الاسم الكامل', validators=[DataRequired(), Length(min=2, max=100)])
    password = PasswordField('كلمة المرور', validators=[DataRequired(), Length(min=6)])
    confirm_password = PasswordField('تأكيد كلمة المرور', 
                                   validators=[DataRequired(), EqualTo('password')])
    is_admin = BooleanField('مدير النظام')

class CourseForm(FlaskForm):
    title = StringField('عنوان المقرر', validators=[DataRequired(), Length(max=200)])
    description = TextAreaField('وصف المقرر', validators=[Optional()])
    content = TextAreaField('محتوى المقرر', validators=[DataRequired()], widget=TextArea())
    image_url = StringField('رابط الصورة', validators=[Optional()])
    video_url = StringField('رابط الفيديو', validators=[Optional()])
    is_published = BooleanField('نشر المقرر')

class AssessmentForm(FlaskForm):
    title = StringField('عنوان التقييم', validators=[DataRequired(), Length(max=200)])
    description = TextAreaField('وصف التقييم', validators=[Optional()])
    course_id = SelectField('المقرر', coerce=int, validators=[DataRequired()])
    time_limit = IntegerField('المدة الزمنية (بالدقائق)', validators=[Optional()])
    max_attempts = IntegerField('عدد المحاولات المسموحة', validators=[Optional()], default=1)
    is_published = BooleanField('نشر التقييم')

class QuestionForm(FlaskForm):
    question_text = TextAreaField('نص السؤال', validators=[DataRequired()])
    question_type = SelectField('نوع السؤال', 
                               choices=[('true_false', 'صح أم خطأ'), ('multiple_choice', 'اختيار من متعدد')],
                               validators=[DataRequired()])
    correct_answer = StringField('الإجابة الصحيحة', validators=[DataRequired()])
    option_a = StringField('الخيار أ', validators=[Optional()])
    option_b = StringField('الخيار ب', validators=[Optional()])
    option_c = StringField('الخيار ج', validators=[Optional()])
    option_d = StringField('الخيار د', validators=[Optional()])
    points = IntegerField('النقاط', validators=[Optional()], default=1)
