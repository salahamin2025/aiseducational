from flask import render_template, redirect, url_for, flash, request, jsonify
from flask_login import login_user, logout_user, login_required, current_user
from werkzeug.security import check_password_hash, generate_password_hash
from app import app, db
from models import User, Course, Assessment, Question, AssessmentResult, Enrollment
from forms import LoginForm, CreateUserForm, CourseForm, AssessmentForm, QuestionForm
import json
from datetime import datetime

@app.route('/')
def index():
    """Homepage showing platform overview"""
    courses = Course.query.filter_by(is_published=True).limit(6).all()
    return render_template('index.html', courses=courses)

@app.route('/login', methods=['GET', 'POST'])
def login():
    """User login"""
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(username=form.username.data).first()
        if user and check_password_hash(user.password_hash, form.password.data):
            login_user(user)
            flash('تم تسجيل الدخول بنجاح!', 'success')
            next_page = request.args.get('next')
            return redirect(next_page) if next_page else redirect(url_for('dashboard'))
        else:
            flash('اسم المستخدم أو كلمة المرور غير صحيحة', 'danger')
    
    return render_template('login.html', form=form)

@app.route('/logout')
@login_required
def logout():
    """User logout"""
    logout_user()
    flash('تم تسجيل الخروج بنجاح', 'info')
    return redirect(url_for('index'))

@app.route('/dashboard')
@login_required
def dashboard():
    """User dashboard"""
    if current_user.is_admin:
        # Admin dashboard stats
        total_users = User.query.count()
        total_courses = Course.query.count()
        total_assessments = Assessment.query.count()
        recent_users = User.query.order_by(User.created_at.desc()).limit(5).all()
        
        return render_template('dashboard.html', 
                             total_users=total_users,
                             total_courses=total_courses,
                             total_assessments=total_assessments,
                             recent_users=recent_users)
    else:
        # Student dashboard
        enrollments = Enrollment.query.filter_by(user_id=current_user.id).all()
        recent_results = AssessmentResult.query.filter_by(user_id=current_user.id)\
                                              .order_by(AssessmentResult.completed_at.desc()).limit(5).all()
        
        return render_template('dashboard.html',
                             enrollments=enrollments,
                             recent_results=recent_results)

@app.route('/admin')
@login_required
def admin():
    """Admin panel"""
    if not current_user.is_admin:
        flash('ليس لديك صلاحية الوصول لهذه الصفحة', 'danger')
        return redirect(url_for('dashboard'))
    
    users = User.query.all()
    courses = Course.query.all()
    assessments = Assessment.query.all()
    
    return render_template('admin.html', users=users, courses=courses, assessments=assessments)

@app.route('/admin/create_user', methods=['GET', 'POST'])
@login_required
def create_user():
    """Create new user (admin only)"""
    if not current_user.is_admin:
        flash('ليس لديك صلاحية لإنشاء مستخدمين جدد', 'danger')
        return redirect(url_for('dashboard'))
    
    form = CreateUserForm()
    if form.validate_on_submit():
        # Check if username or email already exists
        existing_user = User.query.filter(
            (User.username == form.username.data) | (User.email == form.email.data)
        ).first()
        
        if existing_user:
            flash('اسم المستخدم أو البريد الإلكتروني موجود بالفعل', 'danger')
            return render_template('admin.html', form=form)
        
        user = User(
            username=form.username.data,
            email=form.email.data,
            full_name=form.full_name.data,
            password_hash=generate_password_hash(form.password.data),
            is_admin=form.is_admin.data
        )
        
        db.session.add(user)
        db.session.commit()
        flash(f'تم إنشاء المستخدم {user.username} بنجاح', 'success')
        return redirect(url_for('admin'))
    
    return render_template('admin.html', form=form)

@app.route('/admin/edit_user', methods=['POST'])
@login_required
def edit_user():
    """Edit existing user (admin only)"""
    if not current_user.is_admin:
        flash('ليس لديك صلاحية لتعديل المستخدمين', 'danger')
        return redirect(url_for('dashboard'))
    
    user_id = request.form.get('user_id')
    user = User.query.get_or_404(user_id)
    
    # Check if username or email already exists (excluding current user)
    username = request.form.get('username')
    email = request.form.get('email')
    
    existing_user = User.query.filter(
        (User.username == username) | (User.email == email)
    ).filter(User.id != user_id).first()
    
    if existing_user:
        flash('اسم المستخدم أو البريد الإلكتروني موجود بالفعل', 'danger')
        return redirect(url_for('admin'))
    
    # Update user data
    user.username = username
    user.email = email
    user.full_name = request.form.get('full_name')
    user.is_admin = 'is_admin' in request.form
    
    # Update password if provided
    password = request.form.get('password')
    if password:
        user.password_hash = generate_password_hash(password)
    
    db.session.commit()
    flash(f'تم تحديث بيانات المستخدم {user.username} بنجاح', 'success')
    return redirect(url_for('admin'))

@app.route('/admin/delete_user', methods=['POST'])
@login_required
def delete_user():
    """Delete user (admin only)"""
    if not current_user.is_admin:
        flash('ليس لديك صلاحية لحذف المستخدمين', 'danger')
        return redirect(url_for('dashboard'))
    
    user_id = request.form.get('user_id')
    user = User.query.get_or_404(user_id)
    
    # Prevent deletion of admin user
    if user.username == 'admin':
        flash('لا يمكن حذف مستخدم المدير الأساسي', 'danger')
        return redirect(url_for('admin'))
    
    username = user.username
    db.session.delete(user)
    db.session.commit()
    flash(f'تم حذف المستخدم {username} بنجاح', 'success')
    return redirect(url_for('admin'))

@app.route('/admin/delete_course', methods=['POST'])
@login_required
def delete_course():
    """Delete course (admin only)"""
    if not current_user.is_admin:
        flash('ليس لديك صلاحية لحذف المقررات', 'danger')
        return redirect(url_for('dashboard'))
    
    course_id = request.form.get('course_id')
    course = Course.query.get_or_404(course_id)
    
    title = course.title
    
    # Delete related data first (due to foreign key constraints)
    # Delete assessment results for assessments in this course
    for assessment in course.assessments:
        AssessmentResult.query.filter_by(assessment_id=assessment.id).delete()
        # Delete questions for this assessment
        Question.query.filter_by(assessment_id=assessment.id).delete()
    
    # Delete assessments
    Assessment.query.filter_by(course_id=course_id).delete()
    
    # Delete enrollments
    Enrollment.query.filter_by(course_id=course_id).delete()
    
    # Finally delete the course
    db.session.delete(course)
    db.session.commit()
    
    flash(f'تم حذف المقرر "{title}" بنجاح', 'success')
    return redirect(url_for('admin'))

@app.route('/admin/delete_assessment', methods=['POST'])
@login_required
def delete_assessment():
    """Delete assessment (admin only)"""
    if not current_user.is_admin:
        flash('ليس لديك صلاحية لحذف التقييمات', 'danger')
        return redirect(url_for('dashboard'))
    
    assessment_id = request.form.get('assessment_id')
    assessment = Assessment.query.get_or_404(assessment_id)
    
    title = assessment.title
    
    # Delete related data first
    AssessmentResult.query.filter_by(assessment_id=assessment_id).delete()
    Question.query.filter_by(assessment_id=assessment_id).delete()
    
    # Delete the assessment
    db.session.delete(assessment)
    db.session.commit()
    
    flash(f'تم حذف التقييم "{title}" بنجاح', 'success')
    return redirect(url_for('admin'))

@app.route('/courses')
@login_required
def courses():
    """List all published courses"""
    courses = Course.query.filter_by(is_published=True).all()
    return render_template('courses.html', courses=courses)

@app.route('/course/<int:course_id>')
@login_required
def course_detail(course_id):
    """Course detail page"""
    course = Course.query.get_or_404(course_id)
    
    if not course.is_published and not current_user.is_admin:
        flash('هذا المقرر غير متاح حاليًا', 'warning')
        return redirect(url_for('courses'))
    
    # Check if user is enrolled
    enrollment = Enrollment.query.filter_by(user_id=current_user.id, course_id=course_id).first()
    assessments = Assessment.query.filter_by(course_id=course_id, is_published=True).all()
    
    return render_template('course_detail.html', course=course, enrollment=enrollment, assessments=assessments)

@app.route('/enroll/<int:course_id>')
@login_required
def enroll_course(course_id):
    """Enroll in a course"""
    course = Course.query.get_or_404(course_id)
    
    if not course.is_published:
        flash('هذا المقرر غير متاح للتسجيل', 'warning')
        return redirect(url_for('courses'))
    
    # Check if already enrolled
    existing_enrollment = Enrollment.query.filter_by(user_id=current_user.id, course_id=course_id).first()
    if existing_enrollment:
        flash('أنت مسجل في هذا المقرر بالفعل', 'info')
        return redirect(url_for('course_detail', course_id=course_id))
    
    enrollment = Enrollment(user_id=current_user.id, course_id=course_id)
    db.session.add(enrollment)
    db.session.commit()
    
    flash(f'تم التسجيل في مقرر "{course.title}" بنجاح', 'success')
    return redirect(url_for('course_detail', course_id=course_id))

@app.route('/admin/create_course', methods=['GET', 'POST'])
@login_required
def create_course():
    """Create new course (admin only)"""
    if not current_user.is_admin:
        flash('ليس لديك صلاحية لإنشاء مقررات جديدة', 'danger')
        return redirect(url_for('dashboard'))
    
    form = CourseForm()
    if form.validate_on_submit():
        course = Course(
            title=form.title.data,
            description=form.description.data,
            content=form.content.data,
            image_url=form.image_url.data if form.image_url.data else None,
            video_url=form.video_url.data if form.video_url.data else None,
            is_published=form.is_published.data
        )
        
        db.session.add(course)
        db.session.commit()
        flash(f'تم إنشاء المقرر "{course.title}" بنجاح', 'success')
        return redirect(url_for('admin'))
    
    return render_template('create_course.html', form=form)

@app.route('/assessments')
@login_required
def assessments():
    """List all assessments for enrolled courses"""
    if current_user.is_admin:
        assessments = Assessment.query.all()
    else:
        # Get assessments for enrolled courses
        enrolled_course_ids = [e.course_id for e in current_user.enrollments]
        assessments = Assessment.query.filter(
            Assessment.course_id.in_(enrolled_course_ids),
            Assessment.is_published == True
        ).all()
    
    return render_template('assessments.html', assessments=assessments)

@app.route('/admin/create_assessment', methods=['GET', 'POST'])
@login_required
def create_assessment():
    """Create new assessment (admin only)"""
    if not current_user.is_admin:
        flash('ليس لديك صلاحية لإنشاء تقييمات جديدة', 'danger')
        return redirect(url_for('dashboard'))
    
    form = AssessmentForm()
    # Populate course choices
    form.course_id.choices = [(c.id, c.title) for c in Course.query.all()]
    
    if form.validate_on_submit():
        assessment = Assessment(
            title=form.title.data,
            description=form.description.data,
            course_id=form.course_id.data,
            time_limit=form.time_limit.data,
            max_attempts=form.max_attempts.data,
            is_published=form.is_published.data
        )
        
        db.session.add(assessment)
        db.session.commit()
        flash(f'تم إنشاء التقييم "{assessment.title}" بنجاح', 'success')
        return redirect(url_for('add_questions', assessment_id=assessment.id))
    
    return render_template('create_assessment.html', form=form)

@app.route('/admin/assessment/<int:assessment_id>/add_questions', methods=['GET', 'POST'])
@login_required
def add_questions(assessment_id):
    """Add questions to assessment (admin only)"""
    if not current_user.is_admin:
        flash('ليس لديك صلاحية لإضافة أسئلة', 'danger')
        return redirect(url_for('dashboard'))
    
    assessment = Assessment.query.get_or_404(assessment_id)
    form = QuestionForm()
    
    if form.validate_on_submit():
        # Prepare options for multiple choice questions
        options = None
        if form.question_type.data == 'multiple_choice':
            options_dict = {}
            if form.option_a.data:
                options_dict['a'] = form.option_a.data
            if form.option_b.data:
                options_dict['b'] = form.option_b.data
            if form.option_c.data:
                options_dict['c'] = form.option_c.data
            if form.option_d.data:
                options_dict['d'] = form.option_d.data
            options = json.dumps(options_dict)
        
        question = Question(
            assessment_id=assessment_id,
            question_text=form.question_text.data,
            question_type=form.question_type.data,
            correct_answer=form.correct_answer.data,
            options=options,
            points=form.points.data,
            order_index=len(assessment.questions)
        )
        
        db.session.add(question)
        db.session.commit()
        flash('تم إضافة السؤال بنجاح', 'success')
        return redirect(url_for('add_questions', assessment_id=assessment_id))
    
    questions = Question.query.filter_by(assessment_id=assessment_id).order_by(Question.order_index).all()
    return render_template('create_assessment.html', form=form, assessment=assessment, questions=questions)

@app.route('/assessment/<int:assessment_id>/take')
@login_required
def take_assessment(assessment_id):
    """Take an assessment"""
    assessment = Assessment.query.get_or_404(assessment_id)
    
    # Check if user is enrolled in the course
    enrollment = Enrollment.query.filter_by(user_id=current_user.id, course_id=assessment.course_id).first()
    if not enrollment and not current_user.is_admin:
        flash('يجب التسجيل في المقرر أولاً لأخذ هذا التقييم', 'warning')
        return redirect(url_for('course_detail', course_id=assessment.course_id))
    
    # Check previous attempts
    previous_attempts = AssessmentResult.query.filter_by(
        user_id=current_user.id, 
        assessment_id=assessment_id
    ).count()
    
    if previous_attempts >= assessment.max_attempts and not current_user.is_admin:
        flash('لقد استنفدت العدد المسموح من المحاولات لهذا التقييم', 'warning')
        return redirect(url_for('assessments'))
    
    questions = Question.query.filter_by(assessment_id=assessment_id).order_by(Question.order_index).all()
    
    if not questions:
        flash('هذا التقييم لا يحتوي على أسئلة بعد', 'warning')
        return redirect(url_for('assessments'))
    
    return render_template('take_assessment.html', assessment=assessment, questions=questions)

@app.route('/assessment/<int:assessment_id>/submit', methods=['POST'])
@login_required
def submit_assessment(assessment_id):
    """Submit assessment answers"""
    assessment = Assessment.query.get_or_404(assessment_id)
    questions = Question.query.filter_by(assessment_id=assessment_id).all()
    
    if not questions:
        flash('هذا التقييم لا يحتوي على أسئلة', 'danger')
        return redirect(url_for('assessments'))
    
    # Calculate score
    user_answers = {}
    total_score = 0
    max_score = sum(q.points for q in questions)
    
    for question in questions:
        user_answer = request.form.get(f'question_{question.id}')
        user_answers[str(question.id)] = user_answer
        
        if user_answer and user_answer.lower() == question.correct_answer.lower():
            total_score += question.points
    
    percentage = (total_score / max_score * 100) if max_score > 0 else 0
    
    # Save result
    result = AssessmentResult(
        user_id=current_user.id,
        assessment_id=assessment_id,
        score=total_score,
        max_score=max_score,
        percentage=percentage,
        answers=json.dumps(user_answers),
        time_taken=int(request.form.get('time_taken', 0))
    )
    
    db.session.add(result)
    db.session.commit()
    
    flash(f'تم تسليم التقييم بنجاح! درجتك: {total_score}/{max_score} ({percentage:.1f}%)', 'success')
    return redirect(url_for('assessment_result', result_id=result.id))

@app.route('/assessment_result/<int:result_id>')
@login_required
def assessment_result(result_id):
    """View assessment result"""
    result = AssessmentResult.query.get_or_404(result_id)
    
    # Check if user can view this result
    if result.user_id != current_user.id and not current_user.is_admin:
        flash('ليس لديك صلاحية لعرض هذه النتيجة', 'danger')
        return redirect(url_for('assessments'))
    
    questions = Question.query.filter_by(assessment_id=result.assessment_id).all()
    user_answers = json.loads(result.answers)
    
    return render_template('assessment_result.html', result=result, questions=questions, user_answers=user_answers)

@app.errorhandler(404)
def not_found(error):
    return render_template('base.html', error_message='الصفحة غير موجودة'), 404

@app.errorhandler(500)
def internal_error(error):
    db.session.rollback()
    return render_template('base.html', error_message='خطأ في الخادم'), 500
